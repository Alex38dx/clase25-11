<?php
require "../config/conexion.php";

$documento = $_POST["documento"];



$sql ="DELETE FROM usuarios 
WHERE documento = '".$documento."' ";

if($dbh->query($sql))
{
    echo " eliminacion  exitoso";
}else
{
    echo "error eliminado";
}



?>