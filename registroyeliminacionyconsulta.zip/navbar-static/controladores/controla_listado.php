<?php

require "../config/conexion.php";


$sql = "SELECT id, nombre, documento 
FROM usuarios 
WHERE 1";

foreach($dbh->query($sql) as $row)
{
     $nombre = $row["nombre"];
     $documento  = $row[2];
     echo "Nombre=".$nombre." -documento=".$documento."<br>";

}

?>