<?php
require "../config/conexion.php";


$nombre = $_POST["nombre"];
$documento = $_POST["documento"];


$sql = "INSERT INTO usuarios
( fecha_sys, nombre, documento)
 VALUES
  (now(),'".$nombre."','".$documento."')";



if($dbh->query($sql))
{
    echo "registro exitoso";
}else
{
    echo "error";
}

?>